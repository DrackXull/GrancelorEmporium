
# Backend (FastAPI)

## Run
```bash
pip install -r backend/requirements.txt
uvicorn backend.main:app --reload --port 8000
```
API will be at http://localhost:8000
Docs: http://localhost:8000/docs
