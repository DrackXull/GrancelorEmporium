"""
compat_imports: safe imports for models + db access no matter how uvicorn loads us.

Usage in main.py:
    from backend.compat_imports import get_session, init_db, M
"""
from typing import Any

# Models
try:
    from . import models as M  # package-style
except Exception:  # pragma: no cover
    import backend.models as M  # type: ignore

# DB helpers
try:
    from .db import get_session, init_db
except Exception:  # pragma: no cover
    from backend.db import get_session, init_db  # type: ignore
