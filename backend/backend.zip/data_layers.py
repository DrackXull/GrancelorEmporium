from __future__ import annotations
import os, json, glob
from typing import List, Dict, Any, Iterable, Tuple

def _read_json_file(path: str) -> Any:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return None

def _iter_layer_files(layer_root: str, names: Iterable[str]) -> Iterable[Tuple[str, Any]]:
    if not layer_root or not os.path.isdir(layer_root):
        return
    for name in names:
        # arrays in flat files, plus many-file collections
        p = os.path.join(layer_root, name)
        if os.path.isfile(p):
            data = _read_json_file(p)
        if data is not None:
        # Accept array[] or object{} maps or wrapper {"classes":[...]}
            if isinstance(data, dict):
            # wrapper-list detection: use singular/plural name
                base = os.path.splitext(name)[0]   # e.g., "classes"
            wrapped = data.get(base)
            if isinstance(wrapped, list):
                data = wrapped
            else:
                # plain map of id->record
                vals = list(data.values())
                if vals and all(isinstance(v, dict) for v in vals):
                    data = vals
        yield (name, data)

        # support folders like monsters/*.json
        folder = os.path.join(layer_root, os.path.splitext(name)[0])
        if os.path.isdir(folder):
            items = []
            for fp in sorted(glob.glob(os.path.join(folder, "*.json"))):
                d = _read_json_file(fp)
                if isinstance(d, dict):
                    items.append(d)
                elif isinstance(d, list):
                    items.extend(d)
            if items:
                yield (name, items)

def _key_of(rec: Dict[str, Any]):
    return rec.get("id") or rec.get("name")

def _merge_arrays(arrays: List[List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
    by_id: Dict[str, Dict[str, Any]] = {}
    for arr in arrays:
        if not isinstance(arr, list): continue
        for r in arr:
            if not isinstance(r, dict): continue
            k = _key_of(r)
            if not k:  # skip unkeyed records
                continue
            cur = by_id.get(k, {})
            cur.update(r)  # last-writer-wins on fields
            by_id[k] = cur
    return list(by_id.values())

def build_layers(backend_root: str, ruleset: str, campaign: str | None) -> List[str]:
    d = lambda *p: os.path.join(backend_root, "data", *p)
    layers = []
    # 1) system base
    layers.append(d("systems", ruleset))
    # 2) system homebrew (optional)
    layers.append(d("systems", ruleset, "homebrew"))
    # 3) campaign system folder
    if campaign:
        layers.append(d("campaigns", campaign, ruleset))
        # 4) campaign shared
        layers.append(d("campaigns", campaign, "shared"))
    # 5) runtime overrides
    layers.append(d("runtime", "overrides", ruleset))
    return [p for p in layers if os.path.isdir(p)]

def load_collections(backend_root: str, ruleset: str, campaign: str | None, names: List[str]) -> Dict[str, List[Dict[str, Any]]]:
    layers = build_layers(backend_root, ruleset, campaign)
    out: Dict[str, List[Dict[str, Any]]] = {}
    for name in names:
        arrays: List[List[Dict[str, Any]]] = []
        for layer in layers:
            for fname, data in _iter_layer_files(layer, [name]):
                if fname != name: continue
                if isinstance(data, list):
                    arrays.append(data)
                elif isinstance(data, dict):
                    arrays.append([data])
        out[name] = _merge_arrays(arrays)
    return out
