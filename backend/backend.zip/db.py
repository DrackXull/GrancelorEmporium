import os
from contextlib import contextmanager
from typing import Iterator, Optional

from sqlmodel import SQLModel, Session, create_engine


# Resolve DB path (SQLite by default; can be swapped to Postgres via env)
def _default_sqlite_url() -> str:
    here = os.path.abspath(os.path.dirname(__file__))
    db_path = os.path.join(here, "app.db")
    return f"sqlite:///{db_path}"

DATABASE_URL = os.environ.get("TPKA_DATABASE_URL", _default_sqlite_url())

# SQLite needs check_same_thread for multi-threaded uvicorn
_engine_kwargs = {}
if DATABASE_URL.startswith("sqlite"):
    _engine_kwargs.update({"connect_args": {"check_same_thread": False}})

engine = create_engine(DATABASE_URL, echo=False, **_engine_kwargs)


def init_db() -> None:
    """Create tables if they don't exist. Alembic can take over later."""
    from . import models  # ensure models are imported before create_all
    SQLModel.metadata.create_all(engine)


@contextmanager
def get_session() -> Iterator[Session]:
    with Session(engine) as session:
        yield session
