#!/usr/bin/env python3
import json, sys, pathlib
ROOT = pathlib.Path(__file__).resolve().parents[1] / "data"

def norm(path):
    p = ROOT / path
    with p.open("r", encoding="utf-8") as f:
        data = json.load(f)
    # stable key order, ascii ids preserved
    with p.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2, sort_keys=True)
    print(f"Normalized {path}")

if __name__ == "__main__":
    targets = sys.argv[1:] or [
        "5e/backgrounds.json",
        "5e/weapons.json",
        "5e/armors.json",
        "pf2e/classes.json",
        "pf2e/traits.json",
        "pf2e/runes.json",
        "runtime/classes_overrides.json"
    ]
    for t in targets: norm(t)
