// frontend/src/components/MonteCarloPanel.jsx
import { useEffect, useMemo, useState } from "react";

const API = import.meta.env.VITE_API_URL || "http://localhost:8000/api";

export default function MonteCarloPanel() {
  const [types, setTypes] = useState([]);
  const [form, setForm] = useState({
    runs: 100000,
    baseRoll: "1d8+3",
    damageType: "fire",
    resistMultiplier: 1.0,
    critChance: 0.05,
    critMult: 1.5,
    enableVariance: false,
    varianceRange: 0.03,
    seed: 42
  });
  const [standard, setStandard] = useState(null);
  const [single, setSingle] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetch(`${API}/damage/types`)
      .then(r => r.json())
      .then(d => setTypes(d.damageTypes || []))
      .catch(() => setTypes([]));
  }, []);

  const onChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm(prev => ({
      ...prev,
      [name]: type === "checkbox" ? checked : (name === "runs" || name === "seed")
        ? parseInt(value || 0, 10)
        : (name === "resistMultiplier" || name === "critChance" || name === "critMult" || name === "varianceRange")
          ? parseFloat(value || 0)
          : value
    }));
  };

  const runStandard = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${API}/damage/montecarlo/standard`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          runs: form.runs,
          baseRoll: form.baseRoll,
          damageType: form.damageType,
          critChance: form.critChance,
          critMult: form.critMult,
          enableVariance: form.enableVariance,
          varianceRange: form.varianceRange,
          seed: form.seed
        })
      });
      const data = await res.json();
      setStandard(data);
    } finally {
      setLoading(false);
    }
  };

  const runSingle = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${API}/damage/montecarlo`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const data = await res.json();
      setSingle(data);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-4 max-w-3xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">Monte Carlo Damage Validator</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <label className="flex flex-col">
          <span className="text-sm text-gray-600">Base Roll</span>
          <input name="baseRoll" value={form.baseRoll} onChange={onChange} className="border p-2 rounded" />
        </label>

        <label className="flex flex-col">
          <span className="text-sm text-gray-600">Damage Type</span>
          <select name="damageType" value={form.damageType} onChange={onChange} className="border p-2 rounded">
            {types.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
        </label>

        <label className="flex flex-col">
          <span className="text-sm text-gray-600">Runs</span>
          <input name="runs" type="number" min={1000} step={1000} value={form.runs} onChange={onChange} className="border p-2 rounded" />
        </label>

        <label className="flex flex-col">
          <span className="text-sm text-gray-600">Resist Multiplier</span>
          <input name="resistMultiplier" type="number" step="0.1" value={form.resistMultiplier} onChange={onChange} className="border p-2 rounded" />
        </label>

        <label className="flex flex-col">
          <span className="text-sm text-gray-600">Crit Chance</span>
          <input name="critChance" type="number" step="0.01" value={form.critChance} onChange={onChange} className="border p-2 rounded" />
        </label>

        <label className="flex flex-col">
          <span className="text-sm text-gray-600">Crit Multiplier</span>
          <input name="critMult" type="number" step="0.1" value={form.critMult} onChange={onChange} className="border p-2 rounded" />
        </label>

        <label className="flex gap-2 items-center">
          <input name="enableVariance" type="checkbox" checked={form.enableVariance} onChange={onChange} />
          <span className="text-sm">Enable Variance (±{Math.round(form.varianceRange*100)}%)</span>
        </label>

        <label className="flex flex-col">
          <span className="text-sm text-gray-600">Variance Range</span>
          <input name="varianceRange" type="number" step="0.01" value={form.varianceRange} onChange={onChange} className="border p-2 rounded" />
        </label>

        <label className="flex flex-col">
          <span className="text-sm text-gray-600">Seed (optional)</span>
          <input name="seed" type="number" value={form.seed} onChange={onChange} className="border p-2 rounded" />
        </label>
      </div>

      <div className="flex gap-3 mb-6">
        <button onClick={runSingle} className="px-4 py-2 rounded bg-black text-white disabled:opacity-50" disabled={loading}>
          Run Single Scenario
        </button>
        <button onClick={runStandard} className="px-4 py-2 rounded bg-gray-800 text-white disabled:opacity-50" disabled={loading}>
          Run Standard Set (0.5x / 1.0x / 1.5x / 0x)
        </button>
      </div>

      {single && (
        <div className="mb-6 border rounded p-3">
          <h3 className="font-semibold mb-2">Single Scenario</h3>
          <pre className="text-sm bg-gray-50 p-2 rounded overflow-auto">{JSON.stringify(single, null, 2)}</pre>
        </div>
      )}

      {standard && (
        <div className="border rounded p-3">
          <h3 className="font-semibold mb-2">Standard Scenarios</h3>
          <pre className="text-sm bg-gray-50 p-2 rounded overflow-auto">{JSON.stringify(standard, null, 2)}</pre>
        </div>
      )}
    </div>
  );
}
