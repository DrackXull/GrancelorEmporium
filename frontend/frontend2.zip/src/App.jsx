import { useEffect, useState } from "react";
import NavBar from "./components/NavBar.jsx";
import CreatorPanel from "./components/CreatorPanel.jsx";
import ProgressionPanel from "./components/ProgressionPanel.jsx";
import DataBrowser from "./components/DataBrowser.jsx";
import CompareDrawer from "./components/CompareDrawer.jsx";
import SkillsEditor from "./components/SkillsEditor.jsx";
import SpellCreator from "./pages/SpellCreator";
import SimLab from "./pages/SimLab";
import "./styles.css";

export default function App() {
  const [route, setRoute] = useState("Creator"); // Creator | Progression | Data
  const [apiHealth, setApiHealth] = useState(null);
  const [compareOpen, setCompareOpen] = useState(false);
  const [skillsEditor, setSkillsEditor] = useState(null); // {class_id, ruleset} | null

 useEffect(() => {
  let alive = true;
  let controller = null;
  const isProd = import.meta.env.PROD;
  const BASE_MS = isProd ? 30000 : 5000;   // 30s prod, 5s dev
  const MAX_MS  = isProd ? 120000 : 15000; // cap backoff (2m prod, 15s dev)
  let nextDelay = BASE_MS;
  let timer = null;
  let lastOnline = undefined;

  const schedule = (ms) => {
    clearTimeout(timer);
    timer = setTimeout(tick, ms);
  };

  const tick = async () => {
    if (!alive) return;
    if (document.hidden) {            // pause when tab not visible
      schedule(BASE_MS);
      return;
    }
    try {
      controller?.abort();
      controller = new AbortController();
      const res = await fetch("/api/ping", { cache: "no-store", signal: controller.signal });
      const online = res.ok;
      const j = online ? await res.json() : null;

      // only update if status changed or details differ
      if (online !== lastOnline || (online && JSON.stringify(j) !== JSON.stringify(apiHealth))) {
        setApiHealth(online ? j : null);
        lastOnline = online;
      }

      // reset backoff on success
      nextDelay = BASE_MS;
      schedule(nextDelay);
    } catch {
      // mark offline & backoff
      if (lastOnline !== false) {
        setApiHealth(null);
        lastOnline = false;
      }
      nextDelay = Math.min(Math.round(nextDelay * 1.7), MAX_MS);
      schedule(nextDelay);
    }
  };

  tick(); // immediate
  const vis = () => { if (!document.hidden) { nextDelay = BASE_MS; tick(); } };
  document.addEventListener("visibilitychange", vis);

  return () => {
    alive = false;
    controller?.abort();
    clearTimeout(timer);
    document.removeEventListener("visibilitychange", vis);
  };
}, []); // eslint-disable-line react-hooks/exhaustive-deps



  useEffect(() => {
  const parseHash = () => {
    const h = (location.hash || "").replace(/^#\/?/, "").toLowerCase();
    if (h === "creator") setRoute("Creator");
    else if (h === "data") setRoute("Data");
    else if (h === "sim") setRoute("Sim");
    else if (h === "creator\/spell" || h === "spellcreator") setRoute("SpellCreator");
    // progression deep-links can carry JSON after "Progression-"
    // example: #/progression-{"class_id":"fighter","ruleset":"pf2e"}
    else if (h.startsWith("progression-")) setRoute("Progression-"+decodeURIComponent(h.slice("progression-".length)));
  };
  window.addEventListener("hashchange", parseHash);
  parseHash();
  return () => window.removeEventListener("hashchange", parseHash);
}, []);

useEffect(() => {
  // keep URL in sync for shareable links
  if (route === "Creator") location.hash = "/creator";
  else if (route === "Data") location.hash = "/data";
  else if (route === "Sim") location.hash = "/sim";
  else if (route === "SpellCreator") location.hash = "/creator/spell";
  else if (route.startsWith("Progression-")) location.hash = "/progression-" + encodeURIComponent(route.replace("Progression-",""));
}, [route]);


  return (
    <div className="app-shell">
      <NavBar
        active={route}
        onNavigate={setRoute}
        status={apiHealth?.ok ? "online" : "offline"}
        version={apiHealth?.version}
        onOpenCompare={() => setCompareOpen(true)}
      />
      <main className="main">
        {route === "Creator" && (
          <CreatorPanel
            onOpenProgression={(q) => setRoute("Progression-"+JSON.stringify(q))}
            onOpenSkills={(c) => setSkillsEditor(c)}
          />
        )}
        {route.startsWith("Progression") ? (
          <ProgressionPanel initQuery={safeParseRoute(route)} />
        ) : null}
        {route === "Data" && <DataBrowser />}
        {route === "SpellCreator" && <SpellCreator />}
        {route === "Sim" && <SimLab />}

        {compareOpen && <CompareDrawer onClose={() => setCompareOpen(false)} />}
        {skillsEditor && (
          <SkillsEditor
            classId={skillsEditor.class_id}
            ruleset={skillsEditor.ruleset}
            onClose={() => setSkillsEditor(null)}
          />
        )}
      </main>
      <footer className="footer">
        <span>Grancelor’s Emporium · Phase 4</span>
        {apiHealth?.service && <span className="muted">API: {apiHealth.service} v{apiHealth.version}</span>}
      </footer>
    </div>
  );
}

function safeParseRoute(route) {
  try {
    if (!route.startsWith("Progression-")) return null;
    return JSON.parse(route.replace("Progression-",""));
  } catch { return null; }
}
