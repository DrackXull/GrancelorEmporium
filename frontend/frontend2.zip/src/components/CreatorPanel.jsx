import { useEffect, useMemo, useState } from "react";
import Chip from "./Chip.jsx";

export default function CreatorPanel({ onOpenProgression, onOpenSkills }) {
  const [ruleset, setRuleset] = useState("5e");
  const [catalog, setCatalog] = useState(null);
  const [classId, setClassId] = useState("");
  const [level, setLevel] = useState(1);
  const [subclassId, setSubclassId] = useState("");
  const [payload, setPayload] = useState(null);
  const [saving, setSaving] = useState(false);
  const [loadoutName, setLoadoutName] = useState("");
  const [showPf2Derived, setShowPf2Derived] = useState(false);

  useEffect(() => { fetchCatalog(); }, [ruleset]);

  useEffect(() => {
    if (classId) {
      fetch(`/api/creator/default?class_id=${encodeURIComponent(classId)}&ruleset=${ruleset}&level=${level}`)
        .then(r => r.json()).then(setPayload).catch(() => setPayload(null));
    } else {
      setPayload(null);
    }
  }, [ruleset, classId, level]);

  const cls = useMemo(() => (catalog?.classes || []).find(c => c.id === classId || c.archetype === classId), [catalog, classId]);

  function fetchCatalog() {
    fetch(`/api/creator/catalog?ruleset=${ruleset}`)
      .then(r => r.json())
      .then(setCatalog)
      .catch(() => setCatalog(null));
  }

  function saveLoadout() {
    if (!classId || !loadoutName || !payload) return;
    setSaving(true);
    const body = {
      class_id: classId,
      ruleset,
      loadout_name: loadoutName,
      payload: {
        ability_scores: payload.ability_scores,
        weapon_id: payload.weapon_id,
        armor_id: payload.armor_id,
        ancestry_id: payload.ancestry_id,
        background_id: payload.background_id,
        feat_ids: payload.feat_ids || [],
        spell_ids: payload.spell_ids || [],
      }
    };
    fetch("/api/creator/save_default", { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify(body) })
      .then(r => r.json())
      .then(() => { setSaving(false); fetchCatalog(); })
      .catch(() => setSaving(false));
  }

  function openInProgression() {
    onOpenProgression?.({
      ruleset,
      class_id: classId,
      level: Number(level) || 1,
      subclass_id: subclassId || undefined,
      pf2e_full_ac: showPf2Derived || undefined,
    });
  }

  return (
    <section className="panel">
      <div className="panel-header">
        <h2>Creator</h2>
        <div className="panel-actions">
          {ruleset === "pf2e" && classId && (
            <button className="btn ghost" onClick={() => onOpenSkills?.({ class_id: classId, ruleset })}>
              Skills Editor
            </button>
          )}
          <button className="btn" onClick={openInProgression} disabled={!classId}>Open in Progression ↗</button>
        </div>
      </div>

      <div className="grid two">
        <div className="card">
          <div className="field">
            <label>Ruleset</label>
            <select value={ruleset} onChange={e=>setRuleset(e.target.value)}>
              <option value="5e">5e</option>
              <option value="pf2e">PF2e</option>
            </select>
          </div>

          <div className="field">
            <label>Class</label>
            <select value={classId} onChange={e=>{ setClassId(e.target.value); setSubclassId(""); }}>
              <option value="">— select —</option>
              {(catalog?.classes || []).map(c=>(
                <option key={c.id||c.archetype} value={c.id||c.archetype}>{c.name}</option>
              ))}
            </select>
          </div>

          <div className="field">
            <label>Level</label>
            <input type="number" min="1" max="20" value={level} onChange={e=>setLevel(e.target.value)} />
          </div>

          {cls && (cls.subclasses?.length ? (
            <div className="field">
              <label>Subclass</label>
              <select value={subclassId} onChange={e=>setSubclassId(e.target.value)}>
                <option value="">— none —</option>
                {cls.subclasses.map(s=>(
                  <option key={s.id||s.archetype} value={s.id||s.archetype}>{s.name || (s.id||s.archetype)}</option>
                ))}
              </select>
              <small className="muted">Unlock level: {cls.subclass_unlock ?? (ruleset==="5e" ? 3 : 2)}</small>
            </div>
          ) : <div className="field"><label>Subclass</label><div className="muted">— N/A —</div></div>)}

          {ruleset === "pf2e" && (
            <div className="field row">
              <label>PF2e Derived AC</label>
              <Chip label={showPf2Derived ? "Full (proficiency bumps applied)" : "Simple"} active={showPf2Derived} onClick={()=>setShowPf2Derived(!showPf2Derived)} />
            </div>
          )}
        </div>

        <div className="card">
          <h3>Preview</h3>
          {!payload ? <div className="muted">Pick a class + level…</div> : (
            <div className="cols two">
              <div>
                <div className="kpi"><div className="kpi-label">AC</div><div className="kpi-value">{payload.ac ?? "—"}</div></div>
                <div className="kpi"><div className="kpi-label">HP</div><div className="kpi-value">{payload.hp ?? "—"}</div></div>
                {ruleset === "5e" && (
                  <div className="kpi"><div className="kpi-label">PB</div><div className="kpi-value">{payload.proficiency_bonus ?? "—"}</div></div>
                )}
              </div>
              <div>
                <div className="block">
                  <div className="label">Weapon</div>
                  <div>{payload.weapon_id || "—"}</div>
                </div>
                <div className="block">
                  <div className="label">Armor</div>
                  <div>{payload.armor_id || "—"}</div>
                </div>
              </div>
            </div>
          )}
          <div className="hr" />
          <div className="row">
            <input
              placeholder="Save loadout as…"
              value={loadoutName}
              onChange={e=>setLoadoutName(e.target.value)}
            />
            <button className="btn" onClick={saveLoadout} disabled={!classId || !loadoutName || saving}>
              {saving ? "Saving…" : "Save Loadout"}
            </button>
          </div>
          {payload?.available_loadouts?.length ? (
            <div className="muted" style={{marginTop:8}}>
              Saved: {payload.available_loadouts.map((l,i)=><span key={i} className="tag">{l.name || l.id}</span>)}
            </div>
          ): null}
        </div>
      </div>
    </section>
  );
}
