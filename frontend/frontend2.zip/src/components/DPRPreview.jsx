// frontend/src/components/DPRPreview.jsx
import React from "react";

export default function DPRPreview({
  weaponDice="1d8",
  strikingRank=0,
  properties=[],
  targetAC=20,
  attackBonus=10,
  strikes=1,
  isAgile=false
}) {
  const [preview, setPreview] = React.useState(null);

  React.useEffect(()=>{
    (async()=>{
      const res = await fetch("/api/dpr/preview_plus", {
        method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({
          weapon_dice: weaponDice,
          striking_rank: strikingRank,
          property_runes: properties,
          target_ac: targetAC,
          attack_bonus: attackBonus,
          strikes,
          is_agile: isAgile
        })
      });
      const j = await res.json();
      setPreview(j);
    })();
  }, [weaponDice, strikingRank, targetAC, attackBonus, strikes, isAgile, JSON.stringify(properties)]); // eslint-disable-line

  if (!preview) return null;
  return (
    <div className="border rounded p-3 text-sm space-y-1">
      <div className="font-semibold">Damage Preview</div>
      <div>Per-hit avg: <b>{preview.avg_per_hit.toFixed(2)}</b></div>
      <div>Total DPR: <b>{preview.dpr_total.toFixed(2)}</b> (over {preview.strikes} strike{preview.strikes>1?"s":""})</div>
      <div className="text-xs text-gray-600">Crit rules included, MAP: {preview.map_penalties.join(", ")}</div>
      <div className="text-xs text-gray-600">Breakdown: {preview.breakdown}</div>
    </div>
  );
}
