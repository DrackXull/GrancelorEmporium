// frontend/src/components/DPRPreviewAuto.jsx
import React from "react";

export default function DPRPreviewAuto({
  classId, level,
  weaponId, weaponDice="1d8",
  abilityMod=4, potency=2, strikingRank=1,
  properties=[], targetAC=24, strikes=2, isAgile=false
}) {
  const [res, setRes] = React.useState(null);

  React.useEffect(()=>{
    (async()=>{
      const r = await fetch("/api/dpr/preview_from_build", {
        method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({
          class_id: classId, level,
          weapon_id: weaponId, weapon_dice: weaponDice,
          ability_mod: abilityMod, potency, striking_rank: strikingRank,
          property_runes: properties, target_ac: targetAC, strikes, is_agile: isAgile
        })
      });
      setRes(await r.json());
    })();
  }, [classId, level, weaponId, weaponDice, abilityMod, potency, strikingRank, targetAC, strikes, isAgile, JSON.stringify(properties)]); // eslint-disable-line

  if (!res) return null;
  return (
    <div className="border rounded p-3 text-sm space-y-1">
      <div className="font-semibold">Damage Preview (Auto)</div>
      <div>Attack bonus (derived): <b>+{res.attack_bonus}</b></div>
      <div>Per-hit avg: <b>{res.avg_per_hit.toFixed(2)}</b></div>
      <div>Total DPR: <b>{res.dpr_total.toFixed(2)}</b> (over {res.strikes} strike{res.strikes>1?"s":""})</div>
      <div className="text-xs text-gray-600">MAP: {res.map_penalties.join(", ")}</div>
      <div className="text-xs text-gray-600">Breakdown: {res.breakdown}</div>
    </div>
  );
}
