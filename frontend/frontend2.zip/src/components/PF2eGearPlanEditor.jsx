// frontend/src/components/PF2eGearPlanEditor.jsx
import React from "react";

export default function PF2eGearPlanEditor({ classId }) {
  const [plan, setPlan] = React.useState({ by_level:{} });
  const [validation, setValidation] = React.useState({});
  const [runeSuggestW, setRuneSuggestW] = React.useState([]);
  const [runeSuggestA, setRuneSuggestA] = React.useState([]);

  async function load() {
    const r = await fetch(`/api/gear/plan/${encodeURIComponent(classId)}`);
    const j = await r.json();
    setPlan(j?.plan || { by_level:{} });
    await validate();
  }
  async function validate() {
    const r = await fetch(`/api/validate/pf2e_gear_plan?class_id=${encodeURIComponent(classId)}`);
    const j = await r.json();
    setValidation(j?.issues_by_level || {});
  }
  React.useEffect(()=>{ load(); }, [classId]); // eslint-disable-line
  React.useEffect(()=>{
    (async()=>{
      const w = await (await fetch("/api/runes/suggest?slot=weapon")).json();
      const a = await (await fetch("/api/runes/suggest?slot=armor")).json();
      setRuneSuggestW(w?.runes || []);
      setRuneSuggestA(a?.runes || []);
    })();
  }, []);

  function rowFor(level){
    const key = String(level);
    return plan.by_level[key] || { weapon:{potency:0,striking_rank:0,properties:[]}, armor:{potency:0,resilient_rank:0,properties:[]} };
  }
  async function saveRow(level, nextRow){
    const body = { level, row: nextRow };
    await fetch(`/api/gear/plan/${encodeURIComponent(classId)}`,{
      method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify(body)
    });
    await load();
  }
  async function deleteProp(level, slot, rid){
    const body = { level, slot, rune_id: rid };
    await fetch(`/api/gear/plan/${encodeURIComponent(classId)}/property`,{
      method:"DELETE", headers:{"Content-Type":"application/json"}, body: JSON.stringify(body)
    });
    await load();
  }
  async function addProp(level, slot, rid){
    const current = rowFor(level);
    const next = JSON.parse(JSON.stringify(current));
    const arr = (next[slot]?.properties)||[];
    if (!arr.includes(rid)) arr.push(rid);
    await saveRow(level, next);
  }

  return (
    <div className="border rounded p-3 space-y-3">
      <div className="font-semibold">PF2e Gear Plan</div>
      <div className="text-xs text-gray-600">Click a rune chip to remove. Press Enter to add via autocomplete.</div>

      <div className="border rounded">
        <div className="grid grid-cols-12 bg-gray-50 text-xs font-semibold px-2 py-1">
          <div className="col-span-1">Lv</div>
          <div className="col-span-5">Weapon</div>
          <div className="col-span-5">Armor</div>
          <div className="col-span-1 text-right">⚠</div>
        </div>
        {Array.from({length:20}).map((_,i)=>{
          const L = i+1;
          const row = rowFor(L);
          const issues = validation[L] || [];
          const badge = issues.length ? <span className="text-red-600 font-bold">{issues.length}</span> : <span className="text-gray-400">0</span>;
          return (
            <div key={L} className="grid grid-cols-12 px-2 py-1 border-t text-sm items-center">
              <div className="col-span-1">{L}</div>

              {/* Weapon */}
              <div className="col-span-5">
                <div className="flex items-center gap-2 mb-1">
                  <label className="text-xs">Potency</label>
                  <input type="number" min={0} max={3} className="border rounded px-2 py-0.5 w-16"
                         value={row.weapon.potency||0}
                         onChange={e=>{
                           const next = JSON.parse(JSON.stringify(row));
                           next.weapon.potency = Number(e.target.value||0);
                           saveRow(L,next);
                         }}/>
                  <label className="text-xs">Striking</label>
                  <input type="number" min={0} max={3} className="border rounded px-2 py-0.5 w-16"
                         value={row.weapon.striking_rank||0}
                         onChange={e=>{
                           const next = JSON.parse(JSON.stringify(row));
                           next.weapon.striking_rank = Number(e.target.value||0);
                           saveRow(L,next);
                         }}/>
                </div>
                <div className="flex flex-wrap gap-1">
                  {(row.weapon.properties||[]).map(rid=>(
                    <button key={rid} className="px-2 py-0.5 border rounded text-xs"
                            title="Remove" onClick={()=>deleteProp(L,"weapon",rid)}>{rid} ✕</button>
                  ))}
                </div>
                <div className="mt-1">
                  <input className="border rounded px-2 py-1 text-xs w-64" list={`runes-w-${L}`}
                         placeholder="add property rune…" onKeyDown={e=>{
                           if(e.key==="Enter"){ const v=e.currentTarget.value.trim(); if(v){ addProp(L,"weapon",v); e.currentTarget.value=""; } }
                         }}/>
                  <datalist id={`runes-w-${L}`}>
                    {runeSuggestW.map(r=><option key={r} value={r}>{r}</option>)}
                  </datalist>
                </div>
              </div>

              {/* Armor */}
              <div className="col-span-5">
                <div className="flex items-center gap-2 mb-1">
                  <label className="text-xs">Potency</label>
                  <input type="number" min={0} max={3} className="border rounded px-2 py-0.5 w-16"
                         value={row.armor.potency||0}
                         onChange={e=>{
                           const next = JSON.parse(JSON.stringify(row));
                           next.armor.potency = Number(e.target.value||0);
                           saveRow(L,next);
                         }}/>
                  <label className="text-xs">Resilient</label>
                  <input type="number" min={0} max={3} className="border rounded px-2 py-0.5 w-16"
                         value={row.armor.resilient_rank||0}
                         onChange={e=>{
                           const next = JSON.parse(JSON.stringify(row));
                           next.armor.resilient_rank = Number(e.target.value||0);
                           saveRow(L,next);
                         }}/>
                </div>
                <div className="flex flex-wrap gap-1">
                  {(row.armor.properties||[]).map(rid=>(
                    <button key={rid} className="px-2 py-0.5 border rounded text-xs"
                            title="Remove" onClick={()=>deleteProp(L,"armor",rid)}>{rid} ✕</button>
                  ))}
                </div>
                <div className="mt-1">
                  <input className="border rounded px-2 py-1 text-xs w-64" list={`runes-a-${L}`}
                         placeholder="add armor property…" onKeyDown={e=>{
                           if(e.key==="Enter"){ const v=e.currentTarget.value.trim(); if(v){ addProp(L,"armor",v); e.currentTarget.value=""; } }
                         }}/>
                  <datalist id={`runes-a-${L}`}>
                    {runeSuggestA.map(r=><option key={r} value={r}>{r}</option>)}
                  </datalist>
                </div>
              </div>

              <div className="col-span-1 text-right">{badge}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
