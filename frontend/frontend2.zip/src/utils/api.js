// frontend/src/utils/api.js
import axios from 'axios';

const API_BASE = import.meta.env.VITE_API_BASE || '/api';

const http = axios.create({
  baseURL: API_BASE,
  timeout: 10000,
});

http.interceptors.response.use(
  (response) => response.data,
  (error) => {
    const message =
      error?.response?.data?.detail?.[0]?.msg ||
      error?.response?.data?.detail ||
      error?.message ||
      'Unknown error';
    error.__tpka_message = message;
    return Promise.reject(error);
  }
);

// Power Score and Sim
export async function scoreSpell(spell) {
  return fetchJSON('/api/score/spell', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify(spell)
  });
}

export async function runSim(payload) {
  return fetchJSON('/api/sim/run', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify(payload)
  });
}


// === Saved Searches & Export ===
export async function listSavedSearches() {
  return fetchJSON('/api/searches');
}

export async function saveSearch(name, query) {
  return fetchJSON('/api/searches', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, query }),
  });
}

export async function exportBuildJSON(buildOrId) {
  return fetchJSON('/api/export/build/json', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(buildOrId),
  });
}

export async function exportBuildCSV(buildOrId) {
  return fetchJSON('/api/export/build/csv', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(buildOrId),
  });
}
// --- Power score: spell comparables (nearest 5) ---
export async function spellComparables(spell) {
  return fetchJSON('/api/score/spell/comparables', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify(spell)
  });
}

// --- Power score: monster ---
export async function scoreMonster(mon) {
  return fetchJSON('/api/score/monster', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify(mon)
  });
}




export const fetchAPI = (path, method = 'GET', data = null) => {
  return http({
    url: path,
    method,
    data,
  });
  
};


export default http;
