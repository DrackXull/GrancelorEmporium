import React, { useEffect, useMemo, useState } from "react";

async function http(method, url, body) {
  const opts = { method, headers: { "Content-Type": "application/json" } };
  if (body !== undefined) opts.body = JSON.stringify(body);
  const res = await fetch(url, opts);
  const text = await res.text();
  let json = {};
  try { json = text ? JSON.parse(text) : {}; } catch { json = { __raw: text }; }
  if (!res.ok) throw new Error(json?.message || json?.detail || `HTTP ${res.status}`);
  return json;
}

export default function OverridesEditor({ data, ruleset }) {
  const classes = useMemo(() => data?.classes || [], [data]);

  const [clsId, setClsId] = useState(classes[0]?.id || classes[0]?.archetype || "");
  const [overrides, setOverrides] = useState({ classes: {} });
  const [text, setText] = useState("{\n  \"classes\": {}\n}");
  const [status, setStatus] = useState("");

  useEffect(() => {
    http("GET", "/api/runtime/overrides").then(o => {
      setOverrides(o || { classes: {} });
      setText(JSON.stringify(o || { classes: {} }, null, 2));
    }).catch(e => setStatus(`Failed to load overrides: ${e.message}`));
  }, []);

  const cls = useMemo(() => classes.find(c => c.id===clsId || c.archetype===clsId), [classes, clsId]);
  const current = useMemo(() => (overrides.classes || {})[clsId] || {}, [overrides, clsId]);

  function updateField(field, updater) {
    try {
      const parsed = JSON.parse(text || "{}");
      const oc = parsed.classes || {};
      const target = oc[clsId] || {};
      updater(target);
      oc[clsId] = target;
      parsed.classes = oc;
      setOverrides(parsed);
      setText(JSON.stringify(parsed, null, 2));
    } catch {
      // ignore until valid JSON
    }
  }

  async function save() {
    try {
      const parsed = JSON.parse(text);
      await http("POST", "/api/runtime/overrides", parsed);
      setStatus("Saved overrides and reloaded data ✓");
      setTimeout(()=>setStatus(""), 2000);
    } catch (e) {
      setStatus(`Save failed: ${e.message}`);
    }
  }

  return (
    <section style={{ display: "grid", gap: 12 }}>
      <header style={{ display: "flex", gap: 8, alignItems: "center" }}>
        <h2 style={{ margin: 0 }}>Runtime Overrides</h2>
        <span style={{ opacity: 0.8, fontSize: 12 }}>Class</span>
        <select value={clsId} onChange={(e)=>setClsId(e.target.value)} style={{ padding: "6px 8px", borderRadius: 8 }}>
          {classes.map(c=>(
            <option key={c.id || c.archetype} value={c.id || c.archetype}>{c.name || c.id || c.archetype}</option>
          ))}
        </select>
        <button onClick={()=>updateField("features_by_level", tgt => {
          tgt.features_by_level = tgt.features_by_level || {};
          tgt.features_by_level["5"] = (tgt.features_by_level["5"] || []);
        })} style={btn}>Add FBL skeleton</button>
        <button onClick={()=>updateField("pf2e_weapon_tiers", tgt => {
          tgt.pf2e_weapon_tiers = tgt.pf2e_weapon_tiers || { default:"trained", by_level:{}, overrides:{} };
        })} style={btn}>Add PF2e tiers skeleton</button>
        <button onClick={()=>updateField("defaults", tgt => {
          tgt.defaults = tgt.defaults || { [ruleset]: { level:1, ability_scores:{}, feat_ids:[], spell_ids:[] } };
        })} style={btn}>Add Defaults skeleton</button>
        <button
  onClick={async ()=>{
    try {
      const res = await http("POST", "/api/creator/seed_defaults", { ruleset, force: false });
      alert(`Seeded defaults for ruleset=${ruleset}\nCreated: ${res.created?.length || 0}\nSkipped: ${res.skipped?.length || 0}`);
      // refresh editor contents to show changes
      const o = await http("GET", "/api/runtime/overrides");
      setOverrides(o || { classes: {} });
      setText(JSON.stringify(o || { classes: {} }, null, 2));
    } catch (e) {
      alert(`Seed failed: ${e.message || e}`);
    }
  }}
  style={btn}
  title="Generate base defaults for classes missing them (writes to runtime overrides)"
>
  Generate Defaults (missing)
</button>

        <button onClick={save} style={{ ...btn, marginLeft: "auto" }}>Save</button>
      </header>

      <div style={{ fontSize: 12, opacity: 0.8 }}>
        This file overlays onto <code>classes.json</code>. You can edit any class via <code>overrides.classes[&lt;class_id&gt;]</code>.
      </div>

      <textarea value={text} onChange={e=>setText(e.target.value)} spellCheck={false}
        style={{ width: "100%", height: 420, borderRadius: 10, padding: 12, background:"#0f1424", color:"#e6e6e6", border:"1px solid #253052", fontFamily:"ui-monospace, SFMono-Regular, Menlo, monospace", fontSize:13 }} />

      {status && <div style={{ opacity: 0.9 }}>{status}</div>}

      <details>
        <summary style={{ cursor: "pointer" }}>Current overlay for this class</summary>
        <pre style={{ whiteSpace: "pre-wrap" }}>{JSON.stringify(current, null, 2)}</pre>
      </details>
    </section>
  );
}

const btn = { padding: "6px 10px", borderRadius: 8, border: "1px solid #2a2f42", background:"#152040", color:"#fff", cursor:"pointer" };
