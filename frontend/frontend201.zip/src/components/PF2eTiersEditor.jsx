import { useEffect, useMemo, useState } from "react";

const LVLS = Array.from({length:20}, (_,i)=>String(i+1));

function TierSelect({ value, onChange, tiers }) {
  return (
    <select value={value || ""} onChange={e=>onChange(e.target.value || null)} className="border rounded px-2 py-1">
      <option value="">—</option>
      {tiers.map(t => <option key={t} value={t}>{t.toUpperCase()}</option>)}
    </select>
  );
}

export default function PF2eTiersEditor() {
  const [classes, setClasses] = useState([]);
  const [classId, setClassId] = useState("");
  const [tiers, setTiers] = useState({ default: "", by_level: {}, overrides: {} });
  const [schema, setSchema] = useState({ tiers: ["u","t","e","m","l"] });
  const [weaponGroups, setWeaponGroups] = useState([]);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    fetch("/api/classes?ruleset=pf2e").then(r=>r.json()).then(setClasses).catch(()=>setClasses([]));
    fetch("/api/pf2e/tiers/schema").then(r=>r.json()).then(setSchema).catch(()=>{});
    fetch("/api/weapons/groups").then(r=>r.json()).then(d=>setWeaponGroups(d.groups||[])).catch(()=>{});
  }, []);

  useEffect(() => {
    if (!classId) { setTiers({ default:"", by_level:{}, overrides:{} }); return; }
    fetch(`/api/pf2e/tiers/${encodeURIComponent(classId)}`)
      .then(r=>r.json())
      .then(d => setTiers(d?.tiers || { default:"", by_level:{}, overrides:{} }))
      .catch(()=> setTiers({ default:"", by_level:{}, overrides:{} }));
  }, [classId]);

  function setDefault(v){ setTiers(t => ({...t, default: v || ""})); }
  function setLevel(lvl, v){ setTiers(t => ({...t, by_level: { ...t.by_level, [lvl]: v || "" }})); }
  function removeLevel(lvl){ setTiers(t => { const copy={...t.by_level}; delete copy[lvl]; return {...t, by_level: copy}; }); }

  function setOverride(key, spec){
    setTiers(t => ({...t, overrides: { ...t.overrides, [key]: spec }}));
  }
  function removeOverride(key){
    setTiers(t => { const copy={...t.overrides}; delete copy[key]; return {...t, overrides: copy}; });
  }
  function addOverride(kind){
    const id = prompt(kind==="group" ? "Enter group id (exact, e.g. bows)" : "Enter weapon id (e.g. longsword)");
    if (!id) return;
    const key = kind==="group" ? `group:${id}` : id;
    if (tiers.overrides?.[key]) return; // already exists
    setOverride(key, "");
  }

  async function save() {
    if (!classId) return;
    setBusy(true);
    try {
      const cleanLevels = Object.fromEntries(Object.entries(tiers.by_level || {}).filter(([_,v]) => !!v));
      const cleanOverrides = {};
      for (const [k, spec] of Object.entries(tiers.overrides || {})) {
        if (!spec) continue;
        if (typeof spec === "string") cleanOverrides[k] = spec;
        else {
          const entry = {};
          if (spec.default) entry.default = spec.default;
          const byLevel = Object.fromEntries(Object.entries(spec.by_level || {}).filter(([_,v])=>!!v));
          if (Object.keys(byLevel).length) entry.by_level = byLevel;
          cleanOverrides[k] = Object.keys(entry).length === 1 && entry.default ? entry.default : entry;
        }
      }
      const payload = {
        default: tiers.default || null,
        by_level: cleanLevels,
        overrides: cleanOverrides,
      };
      const r = await fetch(`/api/pf2e/tiers/${encodeURIComponent(classId)}`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(payload),
      });
      await r.json();
      alert("Saved to DB overlay.");
    } catch {
      alert("Save failed");
    } finally {
      setBusy(false);
    }
  }

  async function applyToRuntime() {
    if (!classId) return;
    setBusy(true);
    try {
      const r = await fetch(`/api/pf2e/tiers/${encodeURIComponent(classId)}/apply_runtime`, { method: "POST" });
      const j = await r.json();
      if (j?.ok) {
        alert(`Applied to runtime. Backup: ${j.backup || "n/a"}`);
      } else {
        alert("Apply failed");
      }
    } catch {
      alert("Apply failed");
    } finally {
      setBusy(false);
    }
  }

  async function revertRuntime() {
    if (!confirm("Revert runtime overrides to the most recent backup?")) return;
    setBusy(true);
    try {
      const r = await fetch(`/api/runtime/overrides/revert`, { method: "POST" });
      const j = await r.json();
      if (j?.ok) alert(`Reverted from ${j.restored_from}`);
      else alert(`No backup found.`);
    } catch {
      alert("Revert failed");
    } finally {
      setBusy(false);
    }
  }

  const keys = Object.keys(tiers.overrides || {});

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-2xl font-bold">PF2e Tiers Editor</h1>

      <div className="flex flex-wrap gap-3 items-end">
        <div>
          <label className="block text-sm">Class</label>
          <select disabled={busy} value={classId} onChange={e=>setClassId(e.target.value)} className="border rounded px-2 py-1 min-w-48">
            <option value="">— select —</option>
            {classes.map(c => (<option key={c.id} value={c.id}>{c.name}</option>))}
          </select>
        </div>

        <div>
          <label className="block text-sm">Default Tier</label>
          <TierSelect value={tiers.default || ""} onChange={setDefault} tiers={schema.tiers||[]} />
        </div>

        <div className="flex gap-2">
          <button disabled={busy} onClick={()=>addOverride("weapon")} className="px-3 py-2 rounded border">Add Weapon Override</button>
          <button disabled={busy} onClick={()=>addOverride("group")} className="px-3 py-2 rounded border">Add Group Override</button>
        </div>

        <div className="flex gap-2">
          <button disabled={!classId || busy} onClick={save} className="px-3 py-2 rounded bg-black text-white disabled:opacity-50">Save</button>
          <button disabled={!classId || busy} onClick={applyToRuntime} className="px-3 py-2 rounded border disabled:opacity-50">Apply to Runtime</button>
          <button disabled={busy} onClick={revertRuntime} className="px-3 py-2 rounded border disabled:opacity-50">Revert Runtime</button>
          <button disabled={!classId || busy} onClick={async ()=>{
            const r = await fetch(`/api/pf2e/tiers/${encodeURIComponent(classId)}/export.json`);
            const j = await r.json();
            const pretty = JSON.stringify(j, null, 2);
            const blob = new Blob([pretty], {type:"application/json"});
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url; a.download = `pf2e_tiers_${classId}.overrides.json`; a.click();
            URL.revokeObjectURL(url);
          }} className="px-3 py-2 rounded border disabled:opacity-50">Export JSON</button>
        </div>
      </div>

      {/* By-level table */}
      <div className="border rounded overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-100">
            <tr>
              <th className="text-left px-2 py-1">Level</th>
              <th className="text-left px-2 py-1">Tier</th>
              <th className="text-left px-2 py-1"></th>
            </tr>
          </thead>
          <tbody>
            {LVLS.map(lvl => {
              const v = tiers.by_level?.[lvl] || "";
              return (
                <tr key={lvl} className="border-t">
                  <td className="px-2 py-1">{lvl}</td>
                  <td className="px-2 py-1">
                    <TierSelect value={v} onChange={(val)=>setLevel(lvl, val)} tiers={schema.tiers||[]} />
                  </td>
                  <td className="px-2 py-1">
                    {v ? <button disabled={busy} onClick={()=>removeLevel(lvl)} className="text-xs text-red-600">clear</button> : null}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Overrides */}
      <div className="space-y-2">
        <h2 className="text-lg font-semibold">Overrides</h2>
        {keys.length === 0 && <div className="text-sm text-gray-600">No overrides yet.</div>}
        {keys.map(key => {
          const spec = tiers.overrides[key];
          const isGroup = key.startsWith("group:");
          const title = isGroup ? `Group: ${key.slice(6)}` : `Weapon: ${key}`;
          const valueDefault = typeof spec === "string" ? spec : (spec?.default || "");
          const byLevel = typeof spec === "string" ? {} : (spec?.by_level || {});
          return (
            <div key={key} className="border rounded p-2">
              <div className="flex items-center justify-between">
                <div className="font-medium">{title}</div>
                <button disabled={busy} onClick={()=>removeOverride(key)} className="text-xs text-red-600">remove</button>
              </div>
              <div className="mt-2 flex flex-wrap items-end gap-3">
                <div>
                  <label className="block text-xs">Default</label>
                  <TierSelect value={valueDefault} onChange={(val)=>{
                    if (typeof spec === "string") setOverride(key, val || "");
                    else setOverride(key, { ...(spec||{}), default: val || "" });
                  }} tiers={schema.tiers||[]} />
                </div>
                <div className="text-xs text-gray-600">
                  (Leave default empty and fill per-level below for finer control.)
                </div>
              </div>
              <div className="mt-2 grid grid-cols-5 gap-2">
                {LVLS.map(lvl => {
                  const v = byLevel?.[lvl] || "";
                  return (
                    <div key={lvl} className="flex items-center gap-2">
                      <span className="w-6 text-right text-xs">{lvl}</span>
                      <TierSelect
                        value={v}
                        onChange={(val)=>{
                          const next = { ...(typeof spec==="string" ? {} : (spec||{})) };
                          next.by_level = { ...(next.by_level || {}), [lvl]: val || "" };
                          setOverride(key, next);
                        }}
                        tiers={schema.tiers||[]}
                      />
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {weaponGroups.length > 0 && (
        <div className="text-xs text-gray-600">
          Groups: {weaponGroups.join(", ")}
        </div>
      )}
    </div>
  );
}
