// frontend/src/utils/http.js
const API_BASE = (import.meta.env.VITE_API_BASE ?? "").trim();

function makeUrl(path) {
  const p = path.startsWith("/api") ? path : `/api${path}`;
  return `${API_BASE}${p}`;
}

async function handle(res) {
  const ct = res.headers.get("content-type") || "";
  const data = ct.includes("application/json") ? await res.json() : await res.text();
  if (!res.ok) {
    const err = new Error((data && data.message) || res.statusText);
    err.status = res.status;
    err.__tpka_message = (data && (data.message || data.detail)) || err.message;
    throw err;
  }
  return data;
}

export const http = {
  get: async (path) => handle(await fetch(makeUrl(path), { method: "GET" })),
  post: async (path, body) =>
    handle(
      await fetch(makeUrl(path), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body ?? {}),
      })
    ),
};
