# Open RPG Creative (ORC) License — Notice

Some rules text or mechanics in this project may reference Paizo’s Pathfinder Second Edition rules that Paizo has released under the **Open RPG Creative License (ORC)**. Where we quote or adapt **Licensed Material** under the ORC, we follow the license’s attribution and pass-through requirements. The ORC license text and FAQs are available from Paizo:

- ORC License page: https://paizo.com/orclicense

The ORC license grants rights to use Licensed Material but **does not grant** rights to trademarks or other reserved material. Use of Pathfinder, Starfinder, and Paizo trademarks is governed separately (e.g., the Compatibility License). :contentReference[oaicite:1]{index=1}
