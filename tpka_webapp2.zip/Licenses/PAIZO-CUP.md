# Paizo Community Use Policy (CUP) Attribution

This project includes content that is owned by Paizo Inc. and is used under the terms of the **Paizo Inc. Community Use Policy**. We are not affiliated with Paizo Inc.

- Community Use Policy: https://paizo.com/community/communityuse/
- Community Use Approved Product List: https://paizo.com/community/communityuse/products

> “This work is published under the Paizo Inc. Community Use Policy. We are expressly prohibited from charging you to use or access this content. This work is not published, endorsed, or specifically approved by Paizo. For more information about Paizo Inc. and Paizo products, please visit paizo.com.”

We will only make **non-commercial** use of CUP materials and follow Paizo’s rules regarding Product Identity, trademarks, and proper attribution. The CUP **does not** grant rights to use Paizo’s logos (see the separate Compatibility License if needed). See Paizo’s CUP and FAQ for details. :contentReference[oaicite:0]{index=0}
