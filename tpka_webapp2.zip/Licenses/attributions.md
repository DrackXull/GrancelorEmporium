This work includes material from the System Reference Document 5.x by Wizards of the Coast LLC,
available at https://dnd.wizards.com/resources/systems-reference-document, and is licensed for use under
the Creative Commons Attribution 4.0 International License. © Wizards of the Coast LLC. CC BY 4.0.

This work includes mechanics licensed under the Open RPG Creative (ORC) License.
The ORC License text is © Azora Law. See https://paizo.com/orclicense for details.
No sponsorship or endorsement is implied. ORC License FINAL: © Azora Law. All rights reserved.
