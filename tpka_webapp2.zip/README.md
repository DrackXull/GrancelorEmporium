# docs/DEVELOPMENT.md
# TPKA Webapp — Grancelor’s Emporium (Phase 5)

A fast, modern creator + simulator for PF2e (and friends).  
Current focus: **Data spine → Creator Suite → Sim Lab → Live Sheet**.

---

## TL;DR (Dev Quickstart)

**Requirements**
- Node 18+ (vite)
- Python 3.10+
- `uvicorn`, `fastapi`, `pydantic`
- SQLite (bundled)
- (Optional) ngrok for external tunneling

**Env (root)**
```bash
# .env or shell
TPKA_DB_WRITE=1                # JSON is Source of Truth; mirror writes to SQLite
DSN=sqlite:///backend/tpka.db  # SQLAlchemy DSN
TPKA_RUNTIME_DIR=backend/runtime

tpka_webapp/
├─ backend/
│  ├─ main.py                  # FastAPI app + routes
│  ├─ pf2e.py                  # PF2e Full AC progression helper
│  ├─ power/                   # (planned) scoring engine modules
│  ├─ sim/                     # (planned) combat simulator
│  └─ runtime/
│     └─ searches.json         # saved search storage (writable when DB_WRITE=1)
├─ frontend/
│  ├─ src/
│  │  ├─ components/
│  │  │  ├─ DataBrowser.jsx
│  │  │  ├─ CreatorPanel.jsx
│  │  │  ├─ ProgressionPanel.jsx
│  │  │  └─ ExportButtons.jsx  # export JSON/CSV buttons
│  │  ├─ utils/
│  │  │  └─ api.js             # shared fetch helpers + new endpoints
│  │  └─ main.jsx
│  └─ index.html
└─ docs/
   ├─ DEVELOPMENT.md           # deeper dev guidance
   └─ POWER_SCORING_PF2E.md    # (planned) scoring model details


Backend

cd backend
python -m uvicorn main:app --host 127.0.0.1 --port 8000 --reload


Frontend

cd frontend
npm i
npm run dev


Optional tunnel

ngrok http http://127.0.0.1:5173

What’s shipped

DataBrowser (facet chips + counts, AND/OR, runes autocomplete)

Compare Drawer (/api/compare/builds)

Progression (PF2e “Full AC”; backend emits pf2e_full_ac)

Creator panel hooks (“Open in Progression”, Skills Editor launcher)

Skills Editor (writes overrides; mirrors when TPKA_DB_WRITE=1)

Catalog (runes; /api/catalog?kind=runes)

Saved searches (/api/searches) + shareable URL (?q=...)

Export build JSON/CSV (/api/export/build/json, /api/export/build/csv)

New in this drop

Power scoring (PF2e spell v1): /api/score/spell

Sim Lab skeleton: /api/sim/run

Minimal Spell Creator page (live score + suggested level)

API helpers added in frontend/src/utils/api.js

API cheatsheet
GET  /api/ping
POST /api/progression/summarize/pf2e        # emits per-level pf2e_full_ac
GET  /api/searches                          # saved searches list
POST /api/searches                          # {name, query}
POST /api/export/build/json                 # {build|build_id}
POST /api/export/build/csv                  # {build|build_id}
POST /api/score/spell                       # NEW: power score & suggestion
POST /api/sim/run                           # NEW: sim skeleton

# Development Guide

## Branches
- Current UI polish: `ui-polish-phase5`
- Feature branches: `feat/<area>-<desc>`
- Merge small, iterative PRs

## Data Flow
JSON (SoT) → mirror to SQLite when `TPKA_DB_WRITE=1`.
Runtime artifacts and drafts → `backend/runtime/`.

## Power Scoring (PF2e v1)
Module: `backend/power/pf2e.py`

- `score_spell(spell, context) -> { ps, suggested_level, explain, comparables }`
- **PS** ~ (Damage Throughput × Area Multiplier × Delivery/Save Tax × Range Factor) / (Action Cost × Resource Cost) + Rider Value
- Level bands are kept in-code for now (`LEVEL_BANDS`); we’ll tune with real data.

## Sim Lab (skeleton)
Module: `backend/sim/engine.py`

- Inputs: party, foes, iterations, policy.
- Loop rounds, apply simple DPR/EHP churn with variance.
- Output: winrate, avg rounds, sided DPR/EHP burned.

## Frontend
- Single API surface: `src/utils/api.js`.
- New pages under `src/pages/` (routed in your app shell).
- Keep creator forms snappy; debounce scoring calls (~150ms).

## Next up
- Tune PF2e spell weights with real benchmarks.
- Add ability/monster scoring + comparables.
- Expand Sim Lab policies & action models.
- Live Character Sheet v0.





